<?php
require_once 'bootstrap.php';
require_once __DIR__.'/app/core/PostGuard.php';

$page = $_GET['page'] ?? 'home';
Router::route($page, $pdo);