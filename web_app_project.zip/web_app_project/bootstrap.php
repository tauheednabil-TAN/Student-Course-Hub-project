<?php
session_start();

require_once __DIR__ . '/app/core/Autoloader.php';
require_once __DIR__ . '/app/core/Settings.php';
require_once __DIR__ . '/app/core/Router.php';
require_once __DIR__ . '/config/db.php';

Autoloader::register();