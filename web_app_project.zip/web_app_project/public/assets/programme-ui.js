// programme-ui.js
document.addEventListener('DOMContentLoaded', () => {
  // 1) Programme list filter UI + instant filtering
  const listContainers = document.querySelectorAll('.programme-list, .programmes, ul');
  const isProgrammePage = Array.from(document.querySelectorAll('a')).some(a => /page=programmeDetails/i.test(a.href)) || /page=programmes/i.test(location.search);
  if (isProgrammePage && listContainers.length) {
    const target = listContainers[0];
    if (!document.getElementById('programme-search-bar')) {
      const wrapper = document.createElement('div');
      wrapper.id = 'programme-search-bar';
      wrapper.style.margin = '12px 0';
      wrapper.innerHTML = `
        <form action="index.php" method="get" style="display:flex; gap:8px; max-width:520px;">
          <input type="hidden" name="page" value="programmes">
          <input type="search" name="q" placeholder="Search programmes by name or keyword" aria-label="Search programmes" style="flex:1; padding:8px;">
          <button type="submit" class="btn">Search</button>
        </form>`;
      target.parentNode.insertBefore(wrapper, target);
    }
    const input = document.querySelector('#programme-search-bar input[type="search"]');
    if (input) {
      const filterItems = () => {
        const q = (input.value || '').trim().toLowerCase();
        target.querySelectorAll('li').forEach(li => {
          const text = li.textContent.toLowerCase();
          li.style.display = text.includes(q) ? '' : 'none';
        });
      };
      input.addEventListener('input', filterItems);
    }
  }

  // 2) Toggle modules by year (expects elements grouped with data-year="1"/"2"/"3"...)
  const yearGroups = document.querySelectorAll('[data-year]');
  if (yearGroups.length) {
    const years = Array.from(new Set(Array.from(yearGroups).map(el => el.getAttribute('data-year')))).sort();
    const bar = document.createElement('div');
    bar.style.display='flex'; bar.style.gap='8px'; bar.style.margin='10px 0';
    years.forEach(yr => {
      const btn = document.createElement('button');
      btn.type = 'button'; btn.textContent = `Year ${yr}`;
      btn.addEventListener('click', () => {
        yearGroups.forEach(el => el.style.display = (el.getAttribute('data-year') === yr) ? '' : 'none');
      });
      bar.appendChild(btn);
    });
    const first = yearGroups[0]; first.parentNode.insertBefore(bar, first);
  }

  // 3) Confirmation prompts for delete/destructive actions
  document.body.addEventListener('click', (e) => {
    const t = e.target.closest('[data-confirm], .btn-delete, .danger, .delete');
    if (t && (t.tagName === 'A' || t.tagName === 'BUTTON' || t.closest('form'))) {
      const msg = t.getAttribute('data-confirm') || 'Are you sure you want to proceed?';
      if (!confirm(msg)) e.preventDefault();
    }
  });

  // 4) Client-side validation & sanitization
  function sanitizeValue(v){
    v = (v || '').toString();
    v = v.replace(/\s+/g,' ').trim();            // collapse whitespace
    v = v.replace(/[\x00-\x1F\x7F]/g,'');        // strip control chars
    v = v.replace(/[<>]/g, '');                  // strip angle brackets
    return v;
  }

  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
      let ok = true;
      // Required fields
      form.querySelectorAll('[required]').forEach(inp => {
        const val = sanitizeValue(inp.value);
        if (!val) {
          ok = false;
          inp.setAttribute('aria-invalid','true');
          if (!inp.nextElementSibling || !inp.nextElementSibling.classList.contains('js-error')) {
            const small = document.createElement('small');
            small.className='js-error'; small.style.color='#c00';
            small.textContent='This field is required';
            inp.insertAdjacentElement('afterend', small);
          }
        } else {
          inp.removeAttribute('aria-invalid');
          if (inp.nextElementSibling && inp.nextElementSibling.classList.contains('js-error')) inp.nextElementSibling.remove();
        }
      });

      // Email format
      form.querySelectorAll('input[type="email"]').forEach(inp => {
        const v = sanitizeValue(inp.value);
        const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
        if (!valid) {
          ok = false;
          inp.setAttribute('aria-invalid','true');
          if (!inp.nextElementSibling || !inp.nextElementSibling.classList.contains('js-error')) {
            const small = document.createElement('small');
            small.className='js-error'; small.style.color='#c00';
            small.textContent='Enter a valid email address';
            inp.insertAdjacentElement('afterend', small);
          }
        }
      });

      // Consent checkbox if present
      const consent = form.querySelector('input[name="consent"], #consent');
      if (consent && !consent.checked) {
        ok = false; alert('Please provide consent to proceed.');
      }

      // Sanitize all text inputs
      form.querySelectorAll('input[type="text"], input[type="search"], input[type="tel"], textarea').forEach(inp => {
        inp.value = sanitizeValue(inp.value);
      });

      if (!ok) e.preventDefault();
    });
  });
});