<?php
require_once(__DIR__ . '/../models/programme.php');

class AdminController
{

 public static function login(PDO $pdo)
{
    session_start();

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic input validation
    if ($email === '' || $password === '') {
        header("Location: index.php?page=adminLogin&error=missing_fields");
        exit;
    }

    // Fetch admin by email
    $stmt = $pdo->prepare("SELECT * FROM Admins WHERE Email = :email");
    $stmt->execute(['email' => $email]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify credentials
    if (!$admin || !password_verify($password, $admin['PasswordHash'])) {
        header("Location: index.php?page=adminLogin&error=invalid_credentials");
        exit;
    }

    // Store session
    $_SESSION['admin'] = [
        'id' => $admin['AdminID'],
        'name' => $admin['Name'],
        'email' => $admin['Email']
    ];

    // Redirect to dashboard
    header("Location: index.php?page=adminDashboard");
    exit;
}
    public static function dashboard(PDO $pdo)
    {
         if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (empty($_SESSION['admin']['email'])) {
        header("Location: index.php?page=adminLoginForm&error=unauthorized");
        exit;
    }

        $programmeModel = new Programme($pdo);
        $programmes = $programmeModel->all();
        $modules = $programmeModel->allModules();
        include(__DIR__ . '/../views/admin/admin_dashboard.php');
    }

    public static function editProgramme(PDO $pdo, int $id)
    {
        $programmeModel = new Programme($pdo);
        $programme = $programmeModel->find($id);
        if (!$programme) {
            http_response_code(404);
            include(__DIR__ . '/../views/error/404.php');
            return;
        }
        include(__DIR__ . '/../views/admin/editProgrammeForm.php');
    }

    public static function updateProgramme(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $image = trim($_POST['image'] ?? '');
        $leaderId = (int) ($_POST['leaderId'] ?? null);
        $isPublished = (int) ($_POST['is_published'] ?? 0);

        if ($id <= 0 || !$name || !$description) {
            header("Location: index.php?page=editProgramme&id=$id&error=invalid");
            exit;
        }

        $programmeModel->update($id, $name, $description, $image, $leaderId, $isPublished);
        header('Location: index.php?page=adminDashboard');
        exit;
    }

    public static function deleteProgramme(PDO $pdo, int $id)
    {
        $programmeModel = new Programme($pdo);
        $programmeModel->delete($id);
        header('Location: index.php?page=adminDashboard');
        exit;
    }

    public static function addProgrammeForm(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $levels = $programmeModel->getLevels();
        $staff = $programmeModel->getStaff();
        include(__DIR__ . '/../views/admin/addProgrammeForm.php');
    }

    public static function addProgramme(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $image = trim($_POST['image'] ?? '');
        $levelId = (int) ($_POST['levelId'] ?? 0);
        $leaderId = (int) ($_POST['leaderId'] ?? 0);
        $isPublished = (int) ($_POST['is_published'] ?? 0);

        if (!$name || !$description || $levelId <= 0 || $leaderId <= 0) {
            header("Location: index.php?page=addProgrammeForm&error=invalid");
            exit;
        }

        $programmeModel->insert($name, $description, $image, $levelId, $leaderId, $isPublished);
        header('Location: index.php?page=adminDashboard');
        exit;
    }

    public static function mailingList(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $students = $programmeModel->interestedStudents();
        include(__DIR__ . '/../views/admin/admin_mailing_list.php');
    }

    public static function downloadCSV(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $students = $programmeModel->interestedStudents();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="mailing_list.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Programme', 'Student Name', 'Email', 'Registered At']);

        foreach ($students as $s) {
            fputcsv($output, [$s['ProgrammeName'], $s['StudentName'], $s['Email'], $s['RegisteredAt']]);
        }

        fclose($output);
        exit;
    }
    public static function programmeList(PDO $pdo)
{
    $programmeModel = new Programme($pdo);
    $programmes = $programmeModel->all(); 

    include(__DIR__ . '/../views/admin/programme_list.php');
}
public static function programmeModules(PDO $pdo, ?int $programmeId)
    {
        $programmeModel = new Programme($pdo);
        $programme = $programmeModel->find($programmeId);

        if (!$programme) {
            header("Location: index.php?page=adminDashboard&error=programmeNotFound");
            exit;
        }

        $assigned = $programmeModel->getModules($programmeId);

        foreach ($assigned as &$module) {
            $module['UsageCount'] = $programmeModel->moduleUsageCount($module['ModuleID']);
            $module['UsedInProgrammes'] = $programmeModel->getProgrammesUsingModule($module['ModuleID']);
        }
        unset($module);

        $allModules = $programmeModel->allModules();
        include(__DIR__ . '/../views/admin/programme_modules.php');
    }

    public static function assignModule(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $programmeId = (int) ($_POST['programmeId'] ?? 0);
        $moduleId = (int) ($_POST['moduleId'] ?? 0);
        $year = (int) ($_POST['year'] ?? 1);

        if ($programmeId && $moduleId && $year) {
            $programmeModel->assignModule($programmeId, $moduleId, $year);
        }

        header("Location: index.php?page=programmeModules&id=$programmeId");
        exit;
    }

    public static function removeModule(PDO $pdo, int $programmeId, int $moduleId)
    {
        $programmeModel = new Programme($pdo);
        $programmeModel->removeModule($programmeId, $moduleId);
        header("Location: index.php?page=programmeModules&id=$programmeId");
        exit;
    }

    public static function assignModuleLeaderForm(PDO $pdo, int $moduleId)
    {
        $programmeModel = new Programme($pdo);
        $module = $programmeModel->findModule($moduleId);
        $staff = $programmeModel->getAllStaffForModuleLeader();
        include(__DIR__ . '/../views/admin/assign_module_leader.php');
    }

    public static function assignModuleLeader(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $moduleId = (int) ($_POST['moduleId'] ?? 0);
        $leaderId = (int) ($_POST['staffId'] ?? 0);
        $programmeId = (int) ($_POST['programmeId'] ?? 0);

        if ($moduleId && $leaderId) {
            $programmeModel->updateModuleLeader($moduleId, $leaderId);
        }

        header("Location: index.php?page=programmeModules&id=$programmeId&success=1");
        exit;
    }

    public static function viewInterestedStudents(PDO $pdo, int $programmeId)
    {
        $stmt = $pdo->prepare("SELECT Name, Email, RegisteredAt FROM Students WHERE ProgrammeID = :id ORDER BY RegisteredAt DESC");
        $stmt->execute(['id' => $programmeId]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include(__DIR__ . '/../views/admin/interested_students.php');
    }

    public static function exportEmails(PDO $pdo)
    {
        $programmeId = (int) ($_POST['programmeId'] ?? 0);
        $stmt = $pdo->prepare("SELECT Email FROM Students WHERE ProgrammeID = :id");
        $stmt->execute(['id' => $programmeId]);
        $emails = $stmt->fetchAll(PDO::FETCH_COLUMN);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="interested_emails.csv"');

        $output = fopen('php://output', 'w');
        foreach ($emails as $email) {
            fputcsv($output, [$email]);
        }
        fclose($output);
        exit;
    }

    public static function togglePublish(PDO $pdo, int $id)
    {
        $programmeModel = new Programme($pdo);
        if ($id > 0) {
            $programmeModel->togglePublish($id);
        }
        header('Location: index.php?page=adminDashboard');
        exit;
    }


    public static function loginForm(): void
{
    include(__DIR__ . '/../views/admin/login.php');
}
}