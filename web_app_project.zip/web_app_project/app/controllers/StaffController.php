<?php
class StaffController
{
    public static function loginForm(): void
    {
        include(__DIR__ . '/../views/staff/staff_loginForm.php');
    }

    public static function login(PDO $pdo): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            header("Location: index.php?page=staffLoginForm&error=missing_fields");
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM staff WHERE Email = ?");
        $stmt->execute([$email]);
        $staff = $stmt->fetch();

        if (!$staff || !password_verify($password, $staff['PasswordHash'])) {
            header("Location: index.php?page=staffLoginForm&error=invalid_credentials");
            exit;
        }

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['staff'] = [
            'id' => $staff['StaffID'],
            'name' => $staff['Name'],
            'email' => $staff['Email']
        ];

        header("Location: index.php?page=staffDashboard");
        exit;
    }

    public static function dashboard(PDO $pdo): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $staffId = $_SESSION['staff']['id'] ?? 0;

        $stmt = $pdo->prepare("
            SELECT m.ModuleName, m.Description, p.ProgrammeName
            FROM modules m
            JOIN programmemodules pm ON pm.ModuleID = m.ModuleID
            JOIN programmes p ON pm.ProgrammeID = p.ProgrammeID
            WHERE m.ModuleLeaderID = ?
            ORDER BY m.ModuleID DESC
        ");
        $stmt->execute([$staffId]);
        $modules = $stmt->fetchAll();

        include(__DIR__ . '/../views/staff/staff_dashboard.php');
    }

    public static function impact(PDO $pdo): void
    {
        $staffId = (int) ($_GET['id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT p.ProgrammeName, COUNT(pm.ModuleID) AS ModuleCount
            FROM modules m
            JOIN programmemodules pm ON pm.ModuleID = m.ModuleID
            JOIN programmes p ON pm.ProgrammeID = p.ProgrammeID
            WHERE m.ModuleLeaderID = ?
            GROUP BY p.ProgrammeID, p.ProgrammeName
            ORDER BY ModuleCount DESC
        ");
        $stmt->execute([$staffId]);
        $impact = $stmt->fetchAll();

        $nameStmt = $pdo->prepare("SELECT Name FROM staff WHERE StaffID = ?");
        $nameStmt->execute([$staffId]);
        $staffName = $nameStmt->fetchColumn() ?? 'Unknown';

        include(__DIR__ . '/../views/staff/staff_impact.php');
    }

    public static function modules(PDO $pdo): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $staffId = $_SESSION['staff']['id'] ?? 0;

        $stmt = $pdo->prepare("
            SELECT m.ModuleName, m.Description
            FROM modules m
            WHERE m.ModuleLeaderID = ?
            ORDER BY m.ModuleID DESC
        ");
        $stmt->execute([$staffId]);
        $modules = $stmt->fetchAll();

        include(__DIR__ . '/../views/staff/staff_modules.php');
    }

    public static function logout(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        session_destroy();
        header("Location: index.php?page=staffLoginForm");
        exit;
    }
}