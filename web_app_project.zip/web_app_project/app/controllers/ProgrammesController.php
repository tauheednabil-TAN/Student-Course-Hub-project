<?php
require_once 'config/db.php';

$type = $_GET['type'] ?? '';
$levelId = match($type) {
  'undergrad' => 1,
  'postgrad' => 2,
  default => null
};

if ($levelId !== null) {
  $stmt = $pdo->prepare("SELECT * FROM programmes WHERE LevelID = ? AND is_published = 1");
  $stmt->execute([$levelId]);
} else {
  $stmt = $pdo->query("SELECT * FROM programmes WHERE is_published = 1");
}

$q = trim($_GET['q'] ?? '');
$programmes = $stmt->fetchAll();
if ($q !== '') {
    $programmes = array_values(array_filter($programmes, function($row) use ($q) {
        return stripos($row['ProgrammeName'] ?? '', $q) !== false
            || stripos($row['Description'] ?? '', $q) !== false;
    }));
}
require 'app/views/programmes/list.php';