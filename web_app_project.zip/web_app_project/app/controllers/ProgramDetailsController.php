<?php
require_once 'config/db.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM programmes WHERE ProgrammeID = ?");
$stmt->execute([$id]);
$programme = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM staff WHERE StaffID = ?");
$stmt->execute([$programme['ProgrammeLeaderID'] ?? 0]);
$leader = $stmt->fetch();

$stmt = $pdo->prepare("
  SELECT m.*, pm.Year
  FROM programmemodules pm
  JOIN modules m ON pm.ModuleID = m.ModuleID
  WHERE pm.ProgrammeID = ?
  ORDER BY pm.Year
");
$stmt->execute([$id]);

$modules = [];
foreach ($stmt->fetchAll() as $row) {
  $modules[$row['Year']][] = $row;
}

require 'app/views/students/programme_details.php';