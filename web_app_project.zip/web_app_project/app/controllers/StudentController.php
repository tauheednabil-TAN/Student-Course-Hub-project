<?php

require_once(__DIR__ . '/../models/Programme.php');
require_once(__DIR__ . '/../models/InterestedStudent.php');
require_once(__DIR__ . '/../models/Student.php');

class StudentController
{
    public static function index(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $programmes = $programmeModel->published();
        include(__DIR__ . '/../views/students/programme_lists.php');
    }

    public static function show(PDO $pdo, int $id)
    {
        $programmeModel = new Programme($pdo);
        $id = (int) $id;
        $programme = $programmeModel->find($id);

        if (!$programme || !$programme['is_published']) {
            http_response_code(404);
            include(__DIR__ . '/../views/error/404.php');
            return;
        }

        $modules = $programmeModel->modulesByYear($id);
        $leader = $programmeModel->leader($programme['ProgrammeLeaderID'] ?? null);
        include(__DIR__ . '/../views/students/programme_details.php');
    }

    public static function registerInterest(PDO $pdo)
    {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $programmeId = (int) ($_POST['programmeId'] ?? 0);
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!$name || !$email || !$programmeId || !$password || !$confirmPassword) {
            header("Location: index.php?page=registerInterestForm&error=missing_fields");
            exit;
        }

        if ($password !== $confirmPassword) {
            header("Location: index.php?page=registerInterestForm&error=password_mismatch");
            exit;
        }

        $studentModel = new Student($pdo);
        if ($studentModel->emailExists($email)) {
            header("Location: index.php?page=registerInterestForm&error=email_exists");
            exit;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $studentModel->create($name, $email, $hashedPassword);

        $interestModel = new InterestedStudent($pdo);
        $interestModel->register($name, $email, $programmeId);

        header("Location: index.php?page=thankYou");
        exit;
    }

    public static function showRegisterForm(PDO $pdo)
    {
        $programmeModel = new Programme($pdo);
        $programmes = $programmeModel->all();
        include(__DIR__ . '/../views/students/register_interest_form.php');
    }

    public static function loginForm()
    {
        include(__DIR__ . '/../views/students/login.php');
    }

    public static function login(PDO $pdo)
    {
        if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            header("Location: index.php?page=loginForm&error=missing_fields");
            exit;
        }

        $studentModel = new Student($pdo);
        $student = $studentModel->verifyPassword($email, $password);

        if (!$student) {
            header("Location: index.php?page=loginForm&error=invalid_credentials");
            exit;
        }

        $_SESSION['student'] = [
            'name' => $student['Name'],
            'email' => $student['Email'],
            'id' => $student['StudentID']
        ];

        header("Location: index.php?page=studentDashboard");
        exit;
    }

   public static function studentDashboard(PDO $pdo): void
{
   if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

    // Ensure student is logged in
    if (empty($_SESSION['student']['email'])) {
        header("Location: index.php?page=studentLogin&error=unauthorized");
        exit;
    }

    $email = $_SESSION['student']['email'];

    // Fetch interest rows from model
    $studentModel = new Student($pdo);
    $interests = $studentModel->getInterestRows($email);

    // Pass data to view
    include(__DIR__ . '/../views/students/dashboard.php');
}

public static function programmeList(PDO $pdo): void
{
    // Fetch published programmes with level info
    $stmt = $pdo->query("
        SELECT p.ProgrammeID, p.ProgrammeName, l.LevelID
        FROM programmes p
        LEFT JOIN levels l ON p.LevelID = l.LevelID
        WHERE p.is_published = 1
        ORDER BY p.ProgrammeName ASC
    ");

    $programmes = $stmt->fetchAll();

    // Load the student-facing programme list view
    include(__DIR__ . '/../views/students/programme_lists.php');
}
public static function addInterest(PDO $pdo): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $email = $_SESSION['student']['email'] ?? '';
    $name = $_SESSION['student']['name'] ?? '';
    $programmeId = (int) ($_POST['programme_id'] ?? 0);

    if (!$email || !$programmeId) {
        header("Location: index.php?page=dashboard&error=missing_data");
        exit;
    }

    // Prevent duplicate interest
    $check = $pdo->prepare("SELECT COUNT(*) FROM interestedstudents WHERE Email = ? AND ProgrammeID = ?");
    $check->execute([$email, $programmeId]);
    if ($check->fetchColumn() > 0) {
        header("Location: index.php?page=dashboard&error=already_registered");
        exit;
    }

    // Register interest
    $interestModel = new InterestedStudent($pdo);
    $interestModel->register($name, $email, $programmeId);

    header("Location: index.php?page=dashboard&success=interest_added");
    exit;
}
public static function dashboard(PDO $pdo): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $email = $_SESSION['student']['email'] ?? '';
    if (!$email) {
        header("Location: index.php?page=loginForm");
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT i.RegisteredAt, p.ProgrammeName
        FROM interestedstudents i
        JOIN programmes p ON i.ProgrammeID = p.ProgrammeID
        WHERE i.Email = ?
        ORDER BY i.RegisteredAt DESC
    ");
    $stmt->execute([$email]);
    $interests = $stmt->fetchAll();

    include(__DIR__ . '/../views/students/dashboard.php');
}
}