<?php
// app/views/admin/assign_module_leader.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Assign Module Leader</title>
    <style>
        body { font-family: Arial, sans-serif; padding:18px; }
        label, select, button { display:block; margin:8px 0; }
        select { width:100%; max-width:360px; padding:6px; }
        .muted { color:#666; }
        .actions { margin-top:12px; }
        a.back { margin-right:12px; color:#0366d6; text-decoration:none; }
    </style>
</head>
<body>
    <h2>Assign Module Leader</h2>

    <?php if (empty($module) || !is_array($module)): ?>
        <p class="muted">Module not found.</p>
        <p><a class="back" href="index.php?page=adminDashboard">Back to dashboard</a></p>
        <?php exit; ?>
    <?php endif; ?>

    <p><strong>Assigning Leader to:</strong> <?= htmlspecialchars($module['ModuleName'] ?? 'Untitled') ?></p>

    <form method="post" action="index.php?page=assignModuleLeader">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <input type="hidden" name="moduleId" value="<?= htmlspecialchars($module['ModuleID']) ?>">
        <input type="hidden" name="programmeId" value="<?= htmlspecialchars($programmeId ?? '') ?>">

        <label for="staffId">Select module leader</label>
        <select name="staffId" id="staffId" required>
            <?php if (empty($staff) || !is_array($staff)): ?>
                <option value="">No staff available</option>
            <?php else: ?>
                <?php foreach ($staff as $s): 
                    $sid = htmlspecialchars($s['StaffID']); 
                    $name = htmlspecialchars($s['Name'] ?? $s['Email'] ?? 'Staff');
                    $selected = (isset($module['ModuleLeaderID']) && $module['ModuleLeaderID'] == $s['StaffID']) ? ' selected' : '';
                ?>
                    <option value="<?= $sid ?>"<?= $selected ?>><?= $name ?></option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>

        <div class="actions">
            <button type="submit">Assign Leader</button>
            <a class="back" href="index.php?page=programmeModules&id=<?= htmlspecialchars($programmeId ?? '') ?>">Cancel</a>
        </div>
    </form>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>