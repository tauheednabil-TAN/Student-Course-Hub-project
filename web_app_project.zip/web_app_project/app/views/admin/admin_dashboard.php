<?php
// app/views/admin/admin_dashboard.php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="public/assets/css/admin_dasboard.css">

</head>

<body>
    <h2 style="text-align: center;">Admin Dashboard</h2>
    <div class="admin-actions">
        <a class="action-box" href="index.php?page=addProgrammeForm">
            <h3> Add New Programme</h3>
            <p>Create and publish a new academic programme.</p>
        </a>


        <a class="action-box" href="index.php?page=mailingList">
            <h3> View Mailing List</h3>
            <p>See all students who registered interest.</p>
        </a>


    </div>
    <?php if (empty($programmes) || !is_array($programmes)): ?>
        <p class="muted">No programmes found. Use <a href="index.php?page=addProgrammeForm">Add New Programme</a> to create one.</p>
    <?php else: ?>

        <div class="programme-grid">

            <?php foreach ($programmes as $p):
                $id = isset($p['ProgrammeID']) ? rawurlencode((string)$p['ProgrammeID']) : ''; ?>
                <div class="programme-card">

                    <h3><?= htmlspecialchars($p['ProgrammeName'] ?? 'Untitled') ?></h3>
                    <p><strong>Published:</strong> <?= !empty($p['is_published']) ? 'Yes' : 'No' ?></p>
                    <div class="actions">

                        <a href="index.php?page=editProgramme&id=<?= $id ?>"> Edit</a>
                        <a href="index.php?page=deleteProgramme&id=<?= $id ?>" onclick="return confirm('Are you sure you want to delete this programme?');"> Delete</a>
                        <a href="index.php?page=programmeModules&id=<?= $id ?>">Manage Modules</a>
                        <a href="index.php?page=togglePublish&id=<?= $id ?>" onclick="return confirm('Toggle publish status for this programme?');">
                            <?= !empty($p['is_published']) ? ' Unpublish' : ' Publish' ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
    <?php endif; ?>

    <p><a class="logout" href="index.php?page=adminLogout">Logout</a>
    </p>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>

</html>