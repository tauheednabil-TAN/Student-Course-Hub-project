<?php
// app/views/admin/interested_students.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Interested Students</title>
    <style>
        body { font-family: Arial, sans-serif; padding:18px; }
        table { border-collapse: collapse; width:100%; max-width:100%; margin-top:12px; }
        th, td { border: 1px solid #ddd; padding:8px; text-align:left; }
        th { background:#f6f6f6; }
        a.button { display:inline-block; padding:8px 12px; background:#0366d6; color:#fff; text-decoration:none; border-radius:4px; }
        .muted { color:#666; }
        form { margin-top:12px; }
    </style>
</head>
<body>
    <h2>Interested Students</h2>

    <?php if (empty($students) || !is_array($students)): ?>
        <p class="muted">No interested students found for this programme.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Registered At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $s): 
                    // Data from interestedstudents table 
                    $name = htmlspecialchars($s['StudentName'] ?? $s['Name'] ?? '—');
                    $email = htmlspecialchars($s['Email'] ?? '');
                    $registered = htmlspecialchars($s['RegisteredAt'] ?? '—');
                ?>
                    <tr>
                        <td><?= $name ?></td>
                        <td>
                            <?php if ($email): ?>
                                <a href="mailto:<?= $email ?>"><?= $email ?></a>
                            <?php else: ?>
                                <span class="muted">No email</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $registered ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <form method="post" action="index.php?page=exportEmails" onsubmit="return confirm('Export emails for this programme to CSV?');">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <input type="hidden" name="programmeId" value="<?= htmlspecialchars((string)($programmeId ?? '')) ?>">
        <button type="submit" class="button">Export Emails to CSV</button>
    </form>

    <p style="margin-top:12px;"><a href="index.php?page=adminDashboard">← Back to dashboard</a></p>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>