<?php
// app/views/admin/addProgrammeForm.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Add New Programme</title>
    <style>
        body { font-family: Arial, sans-serif; padding:18px; }
        label { display:block; margin-top:10px; }
        input[type="text"], select, textarea { width:100%; max-width:600px; padding:8px; margin-top:6px; }
        textarea { min-height:100px; }
        .actions { margin-top:12px; }
        a.cancel { margin-left:12px; color:#0366d6; text-decoration:none; }
    </style>
</head>
<body>
    <h2>Add New Programme</h2>

    <?php if (empty($levels) || !is_array($levels) || empty($staff) || !is_array($staff)): ?>
        <p style="color:#c00;">Required data (levels or staff) is missing. Please ensure the controller passed $levels and $staff.</p>
        <p><a href="index.php?page=adminDashboard">Back to dashboard</a></p>
        <?php exit; ?>
    <?php endif; ?>

    <form method="post" action="index.php?page=addProgramme">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <label for="name">Programme Name:</label>
        <input id="name" type="text" name="name" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>

        <label for="image">Image URL:</label>
        <input id="image" type="text" name="image">

        <label for="levelId">Level:</label>
        <select id="levelId" name="levelId" required>
            <?php foreach ($levels as $level):
                $lid = htmlspecialchars((string)($level['LevelID'] ?? ''));
                $lname = htmlspecialchars($level['LevelName'] ?? ''); ?>
                <option value="<?= $lid ?>"><?= $lname ?></option>
            <?php endforeach; ?>
        </select>

        <label for="leaderId">Programme Leader:</label>
        <select id="leaderId" name="leaderId" required>
            <?php foreach ($staff as $s):
                $sid = htmlspecialchars((string)($s['StaffID'] ?? ''));
                $sname = htmlspecialchars($s['Name'] ?? $s['Email'] ?? 'Staff'); ?>
                <option value="<?= $sid ?>"><?= $sname ?></option>
            <?php endforeach; ?>
        </select>

        <label for="is_published">Published:</label>
        <select id="is_published" name="is_published">
            <option value="1">Yes</option>
            <option value="0" selected>No</option>
        </select>

        <div class="actions">
            <button type="submit">Create Programme</button>
            <a class="cancel" href="index.php?page=adminDashboard">Cancel</a>
        </div>
    </form>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>