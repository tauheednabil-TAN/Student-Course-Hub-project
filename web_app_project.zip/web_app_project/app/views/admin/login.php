<?php
// app/views/admin/login.php
function e($v) { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin Login</title>
  <style>
    body { font-family: Arial, sans-serif; margin:40px; }
    .card { max-width:420px; margin:30px auto; padding:18px; border:1px solid #e6e6e6; border-radius:6px; }
    label { display:block; margin-top:12px; font-weight:700; }
    input, button { width:100%; padding:10px; margin-top:6px; box-sizing:border-box; }
    .error { color:#b00; background:#fff0f0; padding:8px; border-radius:4px; }
    .muted { color:#666; font-size:0.95em; margin-top:8px; display:block; }
  </style>
</head>
<body>
  <div class="card">
    <h2 style="margin:0 0 8px 0;">Admin Login</h2>

    <?php if ($error): ?>
      <div class="error">
        <?php
          switch ($error) {
            case 'missing_fields': echo 'Please enter email and password.'; break;
            case 'invalid_credentials': echo 'Invalid email or password.'; break;
            case 'db': echo 'Server error. Try again later.'; break;
            default: echo 'Login error.'; break;
          }
        ?>
      </div>
    <?php endif; ?>

    <form method="post" action="index.php?page=login">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

      <label for="email">Email</label>
      <input id="email" name="email" type="email" required value="<?= e($_POST['email'] ?? '') ?>">

      <label for="password">Password</label>
      <input id="password" name="password" type="password" required>

      <div class="muted">Use an account with <code>role = "admin"</code> to access the dashboard.</div>

      <button type="submit" style="margin-top:14px;">Sign in as Admin</button>
    </form>
  </div>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>