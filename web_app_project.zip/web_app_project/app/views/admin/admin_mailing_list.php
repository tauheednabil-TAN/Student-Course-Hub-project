<?php
// app/views/admin/admin_mailing_list.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Mailing List</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 18px; }
        table { border-collapse: collapse; width: 100%; max-width: 100%; margin-top: 12px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #f6f6f6; }
        a.button { display: inline-block; padding: 8px 12px; background:#0366d6; color:#fff; text-decoration:none; border-radius:4px; }
        .muted { color: #666; }
    </style>
</head>
<body>
    <h2>Mailing List</h2>

    <p><a class="button" href="index.php?page=downloadCSV">Download CSV</a></p>

    <?php if (empty($students) || !is_array($students)): ?>
        <p class="muted">No interested students found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Programme</th>
                    <th>Student Name</th>
                    <th>Email</th>
                    <th>Registered At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s['ProgrammeName'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($s['StudentName'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($s['Email'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($s['RegisteredAt'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>