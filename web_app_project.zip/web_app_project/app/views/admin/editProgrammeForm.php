<?php
// app/views/admin/editProgrammeForm.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Edit Programme</title>
    <style>
        body { font-family: Arial, sans-serif; padding:18px; }
        label { display:block; margin-top:10px; }
        input[type="text"], input[type="number"], textarea, select { width:100%; max-width:600px; padding:8px; margin-top:6px; }
        textarea { min-height:100px; }
        .actions { margin-top:12px; }
        a.cancel { margin-left:12px; color:#0366d6; text-decoration:none; }
    </style>
</head>
<body>
    <h2>Edit Programme</h2>

    <?php if (empty($programme) || !is_array($programme)): ?>
        <p style="color:#c00;">Programme not found.</p>
        <p><a href="index.php?page=adminDashboard">Back to dashboard</a></p>
        <?php exit; ?>
    <?php endif; ?>

    <?php
        $id = htmlspecialchars($programme['ProgrammeID']);
        $name = htmlspecialchars($programme['ProgrammeName'] ?? '');
        $description = htmlspecialchars($programme['Description'] ?? '');
        $image = htmlspecialchars($programme['Image'] ?? '');
        $leaderId = isset($programme['ProgrammeLeaderID']) ? (int)$programme['ProgrammeLeaderID'] : '';
        $isPublished = !empty($programme['is_published']) ? 1 : 0;
    ?>

    <form method="post" action="index.php?page=updateProgramme">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <input type="hidden" name="id" value="<?= $id ?>">

        <label for="name">Programme Name:</label>
        <input id="name" type="text" name="name" value="<?= $name ?>" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?= $description ?></textarea>

        <label for="image">Image URL:</label>
        <input id="image" type="text" name="image" value="<?= $image ?>">

        <label for="leaderId">Programme Leader ID:</label>
        <input id="leaderId" type="number" name="leaderId" value="<?= htmlspecialchars((string)$leaderId) ?>">

        <label for="is_published">Published:</label>
        <select id="is_published" name="is_published">
            <option value="1" <?= $isPublished === 1 ? 'selected' : '' ?>>Yes</option>
            <option value="0" <?= $isPublished === 0 ? 'selected' : '' ?>>No</option>
        </select>

        <div class="actions">
            <button type="submit">Update Programme</button>
            <a class="cancel" href="index.php?page=adminDashboard">Cancel</a>
        </div>
    </form>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>