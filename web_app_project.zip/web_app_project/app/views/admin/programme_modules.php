<?php
// app/views/admin/programme_modules.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Manage Modules</title>
    <style>
        body { font-family: Arial, sans-serif; padding:18px; }
        table { border-collapse: collapse; width:100%; border:1px solid #262121; }
        th, td { padding:10px; text-align:left; vertical-align: top; border:1px solid #e6e6e6; }
        th { background:#f3bebeff; }
        select, button, input { padding:8px; margin-top:8px; }
        #successPopup { background:#d4edda; color:#155724; padding:10px 20px; border:1px solid #c3e6cb; border-radius:5px; font-weight:bold; position:fixed; top:20px; right:20px; z-index:1000; }
        .muted { color:#666; }
        ul.module-programmes { margin:6px 0 0 16px; padding:0; }
        a.action { margin-right:8px; color:#0366d6; text-decoration:none; }
    </style>
</head>
<body>

<?php if (!empty($programme) && is_array($programme)): ?>
    <h2>Modules for <?= htmlspecialchars($programme['ProgrammeName'] ?? 'Untitled') ?></h2>
<?php else: ?>
    <p style="color:#c00; font-weight:bold;">⚠️ Programme not found or invalid ID.</p>
<?php endif; ?>

<?php if (!empty($_GET['success'])): ?>
    <div id="successPopup">Module leader assigned successfully.</div>
<?php endif; ?>

<?php
$progId = isset($programme['ProgrammeID']) ? (int)$programme['ProgrammeID'] : 0;
$allModules = is_array($allModules) ? $allModules : [];
$assigned = is_array($assigned) ? $assigned : [];
?>

<?php if ($progId): ?>
    <form method="post" action="index.php?page=assignModule">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <input type="hidden" name="programmeId" value="<?= $progId ?>">

        <label for="moduleId">Select Module:</label>
        <select name="moduleId" id="moduleId" required>
            <?php foreach ($allModules as $m): 
                $mid = htmlspecialchars((string)($m['ModuleID'] ?? ''));
                $mname = htmlspecialchars($m['ModuleName'] ?? 'Untitled');
            ?>
                <option value="<?= $mid ?>"><?= $mname ?></option>
            <?php endforeach; ?>
        </select>

        <label for="year">Year:</label>
        <select name="year" id="year">
            <option value="1">Year 1</option>
            <option value="2">Year 2</option>
            <option value="3">Year 3</option>
        </select>

        <div style="margin-top:12px;">
            <button type="submit">Assign Module</button>
        </div>
    </form>
<?php else: ?>
    <p class="muted">Cannot assign modules because the programme is not available.</p>
<?php endif; ?>

<h3 style="margin-top:20px;">Assigned Modules</h3>

<?php if (empty($assigned)): ?>
    <p class="muted">No modules assigned to this programme yet.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th style="width:90px;">Year</th>
                <th>Module</th>
                <th style="width:90px;">Code</th>
                <th style="width:220px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($assigned as $a):
                $year = htmlspecialchars((string)($a['Year'] ?? '—'));
                $moduleName = htmlspecialchars($a['ModuleName'] ?? 'Untitled');
                $moduleId = htmlspecialchars((string)($a['ModuleID'] ?? ''));
                $leaderName = !empty($a['LeaderName']) ? htmlspecialchars($a['LeaderName']) : '<em>Not assigned</em>';
                $usage = isset($a['UsageCount']) ? (int)$a['UsageCount'] : 0;
                $usedIn = is_array($a['UsedInProgrammes']) ? $a['UsedInProgrammes'] : [];
            ?>
                <tr>
                    <td>Year <?= $year ?></td>
                    <td>
                        <strong><?= $moduleName ?></strong><br>
                        <small>
                            <strong>Leader:</strong>
                            <?php if (!empty($a['LeaderName'])): ?>
                                <?= $leaderName ?><br>
                            <?php else: ?>
                                <em>Not assigned</em><br>
                            <?php endif; ?>

                            <?php if ($usage > 1): ?>
                                <span style="color:#aa00aa;">🔁 Shared Module (used in <?= $usage ?> programmes)</span><br>
                                <strong>Also used in:</strong>
                                <ul class="module-programmes">
                                    <?php foreach ($usedIn as $p): 
                                        if (!isset($p['ProgrammeID']) || (int)$p['ProgrammeID'] === $progId) continue;
                                        $pname = htmlspecialchars($p['ProgrammeName'] ?? '—');
                                    ?>
                                        <li><?= $pname ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </small>
                    </td>
                    <td><?= $moduleId ?></td>
                    <td>
                        <a class="action" href="index.php?page=assignModuleLeaderForm&id=<?= $moduleId ?>&programmeId=<?= $progId ?>">Assign Leader</a>
                        <a class="action" href="index.php?page=removeModule&programmeId=<?= $progId ?>&moduleId=<?= $moduleId ?>"
                           onclick="return confirm('Remove this module?');">Remove</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<script>
    const popup = document.getElementById('successPopup');
    if (popup) setTimeout(() => { popup.style.display = 'none'; }, 3000);
</script>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>