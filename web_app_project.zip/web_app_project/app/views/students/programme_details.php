<?php
// app/views/students/programme_details.php

// Escape helper
function e($text) {
    return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8');
}

// Defensive checks for required variables
$programme = is_array($programme) ? $programme : null;
$leader = is_array($leader) ? $leader : null;
$modules = is_array($modules) ? $modules : [];
if (!$programme) {
    http_response_code(404);
    echo '<h1>Programme not found</h1>';
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($programme['ProgrammeName']) ?> - Details</title>
    <link rel="stylesheet" href="public/assets/css/style_programme_details.css">
</head>
<body>

  <h1><?= e($programme['ProgrammeName']) ?></h1>

  <p><?= nl2br(e($programme['Description'])) ?></p>

  <?php if (!empty($programme['Image'])): ?>
    <img class="programme-img" src="<?= e($programme['Image']) ?>" alt="Programme image">
  <?php endif; ?>

  <h2>Programme Leader</h2>
  <p><?= e($leader['Name'] ?? 'Not assigned') ?></p>

  <h2>Modules by Year</h2>

  <?php if (empty($modules)): ?>
    <p class="muted">No modules assigned to this programme yet.</p>
  <?php else: ?>
    <?php foreach ($modules as $year => $yearModules): 
        $yearLabel = e($year);
    ?>
      <h3>Year <?= $yearLabel ?></h3>
      <ul class="modules">
        <?php foreach ($yearModules as $module): ?>
          <li>
            <strong><?= e($module['ModuleName'] ?? 'Untitled') ?></strong><br>
            <?= nl2br(e($module['Description'] ?? '')) ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endforeach; ?>
  <?php endif; ?>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>