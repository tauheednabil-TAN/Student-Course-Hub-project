<?php
// app/views/students/programme_lists.php

function e($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

$programmes = is_array($programmes) ? $programmes : [];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Programme List</title>
    <link rel="stylesheet" href="public/assets/css/view_programmes.css">
    <style>
        /* Minimal inline styles to keep the demo readable if CSS missing */
        .container {
            max-width: 1100px;
            margin: 18px auto;
            padding: 0 12px;
            font-family: Arial, sans-serif;
        }

        .programme-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
        }

        .programme-card {
            border: 1px solid #e6e6e6;
            padding: 12px;
            width: 320px;
            box-sizing: border-box;
            border-radius: 6px;
            background: #fff;
        }

        .programme-image {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 4px;
            display: block;
            margin-bottom: 8px;
        }

        .programme-image.placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 160px;
            background: #f6f6f6;
            color: #666;
            border-radius: 4px;
            margin-bottom: 8px;
        }

        footer {
            margin-top: 18px;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Available Programmes</h1>

        <?php if (empty($programmes)): ?>
            <p>No programmes are available at the moment. Please check back later.</p>
        <?php else: ?>
            <ul class="programme-list">
                <?php foreach ($programmes as $programme):
                    $id = (int) ($programme['ProgrammeID'] ?? 0);
                    $name = e($programme['ProgrammeName'] ?? 'Untitled');
                    $desc = e($programme['Description'] ?? '');
                    $img = !empty($programme['Image']) ? e($programme['Image']) : null;
                    $urlId = rawurlencode((string)$id);
                ?>

                    <div style="margin-bottom: 20px; padding: 16px; background: #f9f9fb; border-left: 6px solid #3498db; border-radius: 8px;">
                        <h3 style="margin: 0; font-size: 18px; color: #2c3e50;">
                            <?= htmlspecialchars($p['ProgrammeName'] ?? 'Untitled') ?>
                        </h3>
                        <p style="margin: 6px 0; font-size: 14px; color: #555;">
                            Level: <?= htmlspecialchars($p['LevelName'] ?? '—') ?>
                        </p>
                        <form method="post" action="index.php?page=addInterest">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>
 <input type="hidden" name="programme_id" value="<?= htmlspecialchars($p['ProgrammeID']) ?>">
                            <button type="submit" style="padding: 8px 14px; background-color: #3498db; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
                                ➕ Register Interest
                            </button>
                        </form>
                    </div>


                    <li class="programme-card">
                        <?php if ($img): ?>
                            <img src="<?= $img ?>" alt="<?= $name ?>" class="programme-image">
                        <?php else: ?>
                            <div class="programme-image placeholder">No image</div>
                        <?php endif; ?>

                        <h2><?= $name ?></h2>
                        <p><?= $desc ?></p>
                        <?php if ($id > 0): ?>
                            <a href="index.php?page=programme&id=<?= $urlId ?>">View details</a>
                        <?php else: ?>
                            <span style="color:#666;">Unavailable</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <footer>
            <p>Contact admissions: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
        </footer>
    </div>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>

</html>