<?php
// app/views/students/register_interest_form.php

// Simple escape helper
function e($v)
{
  return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

// Ensure $programmes exists
$programmes = is_array($programmes) ? $programmes : [];
$error = $_GET['error'] ?? '';
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Register Your Interest</title>
  <link rel="stylesheet" href="public/assets/css/style_register_interest.css">
  
  <link rel="stylesheet" href="public/assets/css/style.css">
</head>

<body>

  <h1 style="text-align:center;">Register Your Interest</h1>

  <?php if ($error): ?>
    <p class="error">
      <?php
      switch ($error) {
        case 'password_mismatch':
          echo '! Passwords do not match.';
          break;
        case 'email_exists':
          echo ' !Email already registered.';
          break;
        case 'missing_fields':
          echo '! Please fill in all required fields.';
          break;
        case 'db':
          echo '! Server error. Please try again later.';
          break;
        default:
          echo '! Something went wrong. Please try again.';
          break;
      }
      ?>
    </p>
  <?php endif; ?>

  <?php if (empty($programmes)): ?>
    <p class="muted">No programmes available right now. Please check back later.</p>
  <?php else: ?>
    <?php
    $old = [

      
      'name' => e($_POST['name'] ?? ''),
      'email' => e($_POST['email'] ?? ''),
      'programmeId' => (int)($_POST['programmeId'] ?? 0)
    ];
    ?>
    <form method="post" action="index.php?page=registerInterest" novalidate>
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

      <label for="name">Full Name:</label>
      <input id="name" name="name" type="text" required value="<?= $old['name'] ?>">

      <label for="email">Email Address:</label>
      <input id="email" name="email" type="email" required value="<?= $old['email'] ?>">

      <label for="programmeId">Select Programme:</label>
      <select id="programmeId" name="programmeId" required>
        <?php foreach ($programmes as $p):
          $pid = (int)($p['ProgrammeID'] ?? 0);
          $pname = e($p['ProgrammeName'] ?? 'Untitled');
          $sel = ($pid === $old['programmeId']) ? ' selected' : '';
        ?>
          <option value="<?= $pid ?>" <?= $sel ?>><?= $pname ?></option>
        <?php endforeach; ?>
      </select>

      <label for="password">Create Password:</label>
      <input id="password" name="password" type="password" required minlength="6" autocomplete="new-password">

      <label for="confirm_password">Confirm Password:</label>
      <input id="confirm_password" name="confirm_password" type="password" required minlength="6" autocomplete="new-password">

      <div style="margin-top:12px;">
        <button type="submit">Register Interest</button>
        <a href="index.php" style="margin-left:12px; color:#0366d6; text-decoration:none;">Cancel</a>
      </div>
    </form>
  <?php endif; ?>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>

</html>