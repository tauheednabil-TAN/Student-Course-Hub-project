<?php
// app/views/students/dashboard.php
if (empty($_SESSION['student']['email'])) {
    header('Location: index.php?page=loginForm');
    exit;
}
$name = htmlspecialchars($_SESSION['student']['name'] ?? 'Student');
$email = htmlspecialchars($_SESSION['student']['email'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Dashboard</title>
   <link rel="stylesheet" href="public/assets/css/student_dasboard.css">

</head>
<body>
  <div class="card">
    <h1>Welcome, <?= $name ?></h1>
    <p class="meta"><strong>Email:</strong> <?= $email ?></p>

<?php if (!empty($interests) && is_array($interests)): ?>  <h2 style="margin-top:18px;">Your Registrations</h2>
  <table style="border-collapse:collapse;width:100%;margin-top:8px;">
    <thead>
      <tr>
        <th style="text-align:left;padding:8px;border-bottom:1px solid #2c0606ff;">Programme</th>
        <th style="text-align:left;padding:8px;border-bottom:1px solid #941d1dff;">Registered At</th>
      </tr>
    </thead>
    <tbody>
     <?php foreach ($interests as $r): ?>
        <tr>
      <td style="padding:8px;border-bottom:1px solid #8d1d1dff;">
        <?= htmlspecialchars($r['ProgrammeName'] ?? '—') ?>
      </td>
      <td style="padding:8px;border-bottom:1px solid #8b2222ff;">
        <?= htmlspecialchars($r['RegisteredAt'] ?? '—') ?>
      </td>
    </tr>

      <?php endforeach; ?>
    </tbody>
  </table>
<?php else: ?>
  <p class="meta" style="margin-top:14px;">You have not registered interest in any programmes yet.</p>
<?php endif; ?>
</br>
</br>
<h2 style="margin-top: 30px;">Add Interest in a Programme</h2>

<form method="post" action="index.php?page=addInterest" style="margin-top: 10px;">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

  <select name="programme_id" required
          style="padding: 10px; width: 100%; max-width: 400px; border-radius: 6px; border: 1px solid #ccc; font-size: 16px;">
    <option value="">-- Select a Programme --</option>
    <?php
    $stmt = $pdo->query("SELECT ProgrammeID, ProgrammeName FROM programmes WHERE is_published = 1 ORDER BY ProgrammeName ASC");
    $availableProgrammes = $stmt->fetchAll();
    foreach ($availableProgrammes as $p):
    ?>
      <option value="<?= htmlspecialchars($p['ProgrammeID']) ?>">
        <?= htmlspecialchars($p['ProgrammeName']) ?>
      </option>
    <?php endforeach; ?>
  </select>

  <button type="submit"
          style="margin-top: 12px; padding: 10px 16px; background-color: #3498db; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
    ➕ Register Interest
  </button>
</form>
</br>
</br>
    <p><a class="logout" href="index.php?page=logout">Logout</a>
    </p>
  </div>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>