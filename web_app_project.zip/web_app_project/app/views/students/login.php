<?php
// app/views/students/login.php
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Student Login</title>
  <style>
    body { font-family: Arial, sans-serif; padding:18px; max-width:720px; margin:0 auto; }
    h1 { margin-bottom:12px; }
    form { display:block; margin-top:10px; }
    label { display:block; margin:10px 0 4px; }
    input[type="email"], input[type="password"] { width:100%; max-width:420px; padding:8px; box-sizing:border-box; }
    .error { color:#c00; background:#ffecec; padding:8px; border-radius:4px; margin:8px 0; max-width:420px; }
    button { margin-top:12px; padding:8px 12px; }
  </style>
</head>
<body>

  <h1>Student Login</h1>

  <?php if ($error === 'missing_fields'): ?>
    <div class="error">Please enter both email and password.</div>
  <?php elseif ($error === 'invalid_credentials'): ?>
    <div class="error">Invalid email or password.</div>
  <?php elseif ($error === 'db'): ?>
    <div class="error">A server error occurred. Try again later.</div>
  <?php endif; ?>

  <form method="post" action="index.php?page=login">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

    <label for="email">Email</label>
    <input id="email" name="email" type="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

    <label for="password">Password</label>
    <input id="password" name="password" type="password" required>

    <button type="submit">Login</button>
  </form>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>