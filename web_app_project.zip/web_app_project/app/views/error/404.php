<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Page not found</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { font-family: Arial, sans-serif; padding: 2rem; color:#222; }
    .container { max-width:640px; margin:0 auto; text-align:center; }
    a { color:#0066cc; text-decoration:none; }
    a:focus, a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <div class="container">
    <h1>404 — Page not found</h1>
    <p>Sorry, the page you requested cannot be found.</p>
    <p><a href="index.php">Return to homepage</a></p>
  </div>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>
//hash admin password 
INSERT INTO admins 