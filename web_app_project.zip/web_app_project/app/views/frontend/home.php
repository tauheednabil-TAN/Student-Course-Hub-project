<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My University</title>
    <link rel="stylesheet" href="public/assets/css/style.css">
</head>

<body>

    <header>
        <div class="logo">Niels Brock</div>
        <nav>
            <ul>
                <li>
                    <a href="index.php?page=home">Home</a>
                </li>
                <li><a href="index.php?page=admission">Admissions</a></li>
                
                <li><a href="index.php?page=contact">Contact</a></li>
                <li><a href="index.php?page=about">About</a></li>
                <li class="login-dropdown">
                    <a href="#" id="login-toggle">Login ▾</a>
                    <ul class="login-options" id="login-options">
                        <li><a href="index.php?page=login&type=student">Student</a></li>
                        <li><a href="index.php?page=staffLoginForm" class="login-button">Staff</a></li>
                        <li><a href="index.php?page=login&type=admin">Admin</a></li>
                    </ul>
                 </li>
                 <div class="programme-links">
                    <h2 class="programme-heading">Available Programmes</h2>
                    <div class="programme-buttons">
                        <a href="index.php?page=programmes&type=undergrad" class="btn">Undergraduate</a>
                        <a href="index.php?page=programmes&type=postgrad" class="btn">Postgraduate</a>
                    </div>
                </div>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <h1>Welcome to </br>
            Niels Brock Copenhagen Business College</h1>
        <p>Empowering Education, Inspiring Futures</p>
    </section>

    <section class="cards">
        <div class="card">
            <h3>Study With Us</h3>
            <p>Explore our wide range of programmes.</p>
            <a href="index.php?page=programmes" class="btn">View Programmes</a>
        </div>
        <div class="card">
            <h3>Admissions</h3>
            <p>Find out how to apply and join our community.</p>
            <a href="index.php?page=registerInterestForm" class="btn">Register Your Interest</a>
        </div>
        <div class="card">
            <h3>Student Life</h3>
            <p>Discover campus life, societies, and events.</p>
            <a href="index.php?page=about" class="btn">Learn More</a>
        </div>
    </section>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p>Email: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
                    <p>Phone: +44 (0) 123 456 7890</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Accessibility</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Follow Us</h3>
                    <ul class="social-links">
                        <li><a href="#" aria-label="Facebook">Facebook</a></li>
                        <li><a href="#" aria-label="Twitter">Twitter</a></li>
                        <li><a href="#" aria-label="LinkedIn">LinkedIn</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Student Course Hub. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script>
        function toggleProgrammes() {
            const panel = document.getElementById('programmeOptions');
            panel.style.display = panel.style.display === 'none' ? 'flex' : 'none';
        }
    </script>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>

</html>