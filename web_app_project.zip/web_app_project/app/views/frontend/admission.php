<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admissions - My University</title>
    <link rel="stylesheet" href="public/assets/css/styleadmission.css">
</head>
<body>

  <header>
    <div class="logo">My University</div>
    <nav>
      <ul>
        <li><a href="index.php?page=home">Home</a></li>
        <li><a href="index.php?page=about">About</a></li>
        <li><a href="index.php?page=contact">Contact</a></li>
        <li><a href="index.php?page=loginForm">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="hero small-hero">
    <h1>Admissions</h1>
    <p>Start your journey with us — learn how to apply and join our university.</p>
  </section>

  <main class="content">
    <section>
      <h2>Admission Requirements</h2>
      <ul>
        <li>Completed secondary education or equivalent</li>
        <li>Proof of English proficiency (IELTS/TOEFL)</li>
        <li>Academic transcripts</li>
        <li>Personal statement or motivation letter</li>
      </ul>
    </section>

    <section>
      <h2>Application Process</h2>
      <ol>
        <li>Choose your programme</li>
        <li>Prepare your documents</li>
        <li>Complete the online application form</li>
        <li>Submit before the deadline</li>
        <li>Wait for confirmation and next steps</li>
      </ol>
    </section>

    <section>
      <h2>Important Dates</h2>
      <p>Applications for Fall 2026 open on <strong>January 15</strong> and close on <strong>May 31</strong>.</p>
    </section>

    <section>
      <h2>Ready to Apply?</h2>
      <p>Click below to register your interest or begin your application.</p>
      <a href="index.php?page=registerInterestForm" class="btn">Register Interest</a>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>Contact Us</h3>
          <p>Email: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
          <p>Phone: +44 (0) 123 456 7890</p>
        </div>
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Accessibility</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h3>Follow Us</h3>
          <ul class="social-links">
            <li><a href="#" aria-label="Facebook">Facebook</a></li>
            <li><a href="#" aria-label="Twitter">Twitter</a></li>
            <li><a href="#" aria-label="LinkedIn">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2025 Student Course Hub. All rights reserved.</p>
      </div>
    </div>
  </footer>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>