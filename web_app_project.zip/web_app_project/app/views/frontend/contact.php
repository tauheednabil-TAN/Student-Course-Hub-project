<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - My University</title>
    <link rel="stylesheet" href="public/assets/css/stylecontact.css">
  <link rel="stylesheet" href="public/assets/css/style.css">
</head>
<body>

  <header>
    <div class="logo">My University</div>
    <nav>
      <ul>
        <li><a href="index.php?page=home">Home</a></li>
        <li><a href="index.php?page=about">About</a></li>
        <li><a href="index.php?page=contact">Contact</a></li>
        <li><a href="index.php?page=loginForm">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="hero small-hero">
    <h1>Contact Us</h1>
    <p>We’re here to help — reach out with any questions or feedback.</p>
  </section>

  <main class="content">
    <section>
      <h2>Send Us a Message</h2>
      <form action="#" method="POST">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>

</br>

</br>
        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <button type="submit" class="btn">Send Message</button>
      </form>
    </section>

    <section>
      <h2>University Contact Information</h2>
      <p><strong>Address:</strong> 123 University Road, Copenhagen, Denmark</p>
      <p><strong>Phone:</strong> +45 12 34 56 78</p>
      <p><strong>Email:</strong> info@myuni.edu</p>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>Contact Us</h3>
          <p>Email: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
          <p>Phone: +44 (0) 123 456 7890</p>
        </div>
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Accessibility</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h3>Follow Us</h3>
          <ul class="social-links">
            <li><a href="#" aria-label="Facebook">Facebook</a></li>
            <li><a href="#" aria-label="Twitter">Twitter</a></li>
            <li><a href="#" aria-label="LinkedIn">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2025 Student Course Hub. All rights reserved.</p>
      </div>
    </div>
  </footer>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>