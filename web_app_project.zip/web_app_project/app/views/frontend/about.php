<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - My University</title>
    <link rel="stylesheet" href="public/assets/css/styleabout.css">
</head>
<body>


  <header>
    <div class="logo">My University</div>
    <nav>
      <ul>
        <li><a href="index.php?page=home">Home</a></li>
        <li><a href="index.php?page=about">About</a></li>
        <li><a href="index.php?page=contact">Contact</a></li>
        <li><a href="index.php?page=loginForm">Login</a></li>
      </ul>
    </nav>
  </header>

  <section class="hero small-hero">
    <h1>About Our University</h1>
    <p>Shaping futures through knowledge, innovation, and community.</p>
  </section>

  <main class="content">
    <section>
      <h2>Our Mission</h2>
      <p>We are committed to providing world-class education and empowering students to achieve their goals.</p>
    </section>

    <section>
      <h2>History</h2>
      <p>Founded in 1970, our university has grown into a vibrant academic community with thousands of students worldwide.</p>
    </section>

    <section>
      <h2>Campus & Facilities</h2>
      <p>Our modern campus includes libraries, labs, sports facilities, and student housing designed to support learning and growth.</p>
    </section>

    <section>
      <h2>Why Choose Us?</h2>
      <ul>
        <li>Wide range of programmes</li>
        <li>International student community</li>
        <li>Strong industry connections</li>
        <li>Supportive learning environment</li>
      </ul>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>Contact Us</h3>
          <p>Email: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
          <p>Phone: +44 (0) 123 456 7890</p>
        </div>
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Accessibility</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h3>Follow Us</h3>
          <ul class="social-links">
            <li><a href="#" aria-label="Facebook">Facebook</a></li>
            <li><a href="#" aria-label="Twitter">Twitter</a></li>
            <li><a href="#" aria-label="LinkedIn">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2025 Student Course Hub. All rights reserved.</p>
      </div>
    </div>
  </footer>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>