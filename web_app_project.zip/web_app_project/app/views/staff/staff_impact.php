<?php

function e($v) { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Programme Impact for <?= e($staffName) ?></title>
  <link rel="stylesheet" href="public/assets/css/staff.css">
  <link rel="stylesheet" href="public/assets/css/theme.css">
</head>
<body>
  <header class="staff-header">
    <h1>Course Hub</h1>
  </header>

  <nav class="staff-nav">
    <a href="index.php?page=staffDashboard" class="active">Dashboard</a>
    <a href="index.php?page=staffModules&id=<?= (int) $staffId ?>">Modules</a>
    <a href="index.php?page=staffImpact&id=<?= (int) $staffId ?>">Impact</a>
    <a href="index.php?page=programmes">Programmes</a>
    <a href="index.php?page=staffLogout">Logout</a>
  </nav>

  <main class="main-content">
    <div class="staff-container">
      <h2>Programme Impact for <?= e($staffName) ?></h2>

      <?php if (empty($impact)): ?>
        <p>This staff member does not impact any programmes at present.</p>
      <?php else: ?>
        <div class="staff-card">
          <table class="staff-card">
            <thead>
              <tr>
                <th>Programme</th>
                <th>Number of Modules Taught</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($impact as $info): ?>
                <tr>
                  <td><?= e($info['ProgrammeName']) ?></td>
                  <td><?= (int) $info['ModuleCount'] ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

      <p class="back-link" style="margin-top: 20px;">
        <a href="index.php?page=staffModules&id=<?= (int) $staffId ?>">← Back to Modules</a>
      </p>
    </div>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>Contact Us</h3>
          <p>Email: <a href="mailto:admissions@example.edu">admissions@example.edu</a></p>
          <p>Phone: +44 (0) 123 456 7890</p>
        </div>
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Accessibility</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h3>Follow Us</h3>
          <ul class="social-links">
            <li><a href="#" aria-label="Facebook">Facebook</a></li>
            <li><a href="#" aria-label="Twitter">Twitter</a></li>
            <li><a href="#" aria-label="LinkedIn">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2025 Student Course Hub. All rights reserved.</p>
      </div>
    </div>
  </footer>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>