<?php
// app/views/staff/staff_loginForm.php
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Staff Login</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to right, #e0eafc, #cfdef3);
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .login-container {
      background-color: white;
      padding: 40px 30px;
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 420px;
    }

    .login-container h1 {
      margin-bottom: 24px;
      color: #153e68;
      font-size: 24px;
      text-align: center;
    }

    .login-container label {
      display: block;
      margin: 12px 0 6px;
      font-weight: bold;
      color: #333;
    }

    .login-container input[type="email"],
    .login-container input[type="password"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 12px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
      box-sizing: border-box;
    }

    .login-container input:focus {
      border-color: #153e68;
      outline: none;
    }

    .login-container button {
      width: 100%;
      padding: 12px;
      background-color: #153e68;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .login-container button:hover {
      background-color: #1a4a80;
    }

    .error {
      color: #c00;
      background: #ffecec;
      padding: 10px;
      border-radius: 6px;
      margin-bottom: 16px;
      font-size: 14px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h1>Staff Login</h1>

    <?php if ($error === 'missing_fields'): ?>
      <div class="error">Please enter both email and password.</div>
    <?php elseif ($error === 'invalid_credentials'): ?>
      <div class="error">Invalid email or password.</div>
    <?php endif; ?>

    <form method="post" action="index.php?page=staffLogin">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

      <label for="email">Email</label>
      <input id="email" name="email" type="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

      <label for="password">Password</label>
      <input id="password" name="password" type="password" required>

      <button type="submit">Login</button>
    </form>
  </div>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>