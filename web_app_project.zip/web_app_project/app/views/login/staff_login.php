<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff_Log_In</title>
  <link rel="stylesheet" href="public/assets/css/style.css">
</head>
<body>
    <h2 style="text-align:center; margin-bottom:20px;">Staff Login</h2>
<form method="POST" action="index.php?page=login&type=staff" style="max-width:400px; margin:0 auto;">
    <?php if (class_exists('Csrf')) echo Csrf::inputField(); ?>

  <label>Email:</label><br>
  <input type="email" name="email" required style="width:100%; padding:10px; margin-bottom:10px;"><br>

  <label>Password:</label><br>
  <input type="password" name="password" required style="width:100%; padding:10px; margin-bottom:20px;"><br>

  <button type="submit" style="width:100%; padding:10px; background:#1e3c72; color:white; border:none; border-radius:5px;">
    Login
  </button>
</form>
    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>
</html>