<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program_list</title>
     <link rel="stylesheet" href="public/assets/css/style_programme_list.css">

</head>

<body>
   <h1><?= ucfirst($_GET['type'] ?? '') ?> Programmes</h1>  <ul>
        <?php foreach ($programmes as $programme): ?><li>
                <a href="index.php?page=programmeDetails&id=<?= $programme['ProgrammeID'] ?>">
                    <?= htmlspecialchars($programme['ProgrammeName']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="index.php?page=home">Back to Home</a>

    <script src="public/assets/programme-ui.js"></script>

    <div class="go-home-box" style="position:fixed; right:16px; bottom:16px; z-index:9999;">
      <a href="index.php?page=home" style="display:inline-block; padding:10px 14px; border-radius:10px; background:#f5f7fb; border:1px solid #dce1ef; 
      box-shadow:0 2px 10px rgba(0,0,0,0.08); text-decoration:none; font-family:system-ui, Arial, sans-serif; color:#1e3c72;">
        ⟵ Go to Homepage
      </a>
    </div>

</body>

</html>