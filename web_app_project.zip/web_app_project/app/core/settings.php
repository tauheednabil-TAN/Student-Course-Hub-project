<?php

class Settings
{
    //  App Info
    public const APP_NAME = 'University Portal';
    public const BASE_URL = 'http://localhost/web_app_project/';

    //  Environment
    public const DEBUG = true;

    public const DB_HOST = 'localhost';
    public const DB_NAME = 'student_course_hub';
    public const DB_USER = 'root';
    public const DB_PASS = '';

    //  Security
    public const SESSION_TIMEOUT = 1800; }