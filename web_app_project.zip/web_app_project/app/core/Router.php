<?php
class Router
{
    public static function route(string $page, PDO $pdo): void
    {
        switch ($page) {

            // Public
            case 'home':
                include(__DIR__ . '/../views/frontend/home.php');
                break;
            case 'programmes':
                require 'app/controllers/ProgrammesController.php';
                break;

            case 'programmeDetails':
                require 'app/controllers/ProgramDetailsController.php';
                break;


            case 'contact':
                include(__DIR__ . '/../views/frontend/contact.php');
                break;

            case 'about':
                include(__DIR__ . '/../views/frontend/about.php');
                break;

            case 'admission':
                include(__DIR__ . '/../views/frontend/admission.php');
                break;


            case 'thankYou':
                include(__DIR__ . '/../views/students/thank_you.php');
                break;



            //  Student
            case 'login':
                $type = $_GET['type'] ?? '';
                require "app/controllers/LoginController.php";
                break;

            case 'login':
                $type = $_GET['type'] ?? '';
                require "app/controllers/LoginController.php";
                break;

            case 'studentDashboard':
                StudentController::studentDashboard($pdo);
                break;
            case 'staffDashboard':
                require('app/views/staff/staff_dashboard.php');
                break;
            case 'adminDashboard':
                require_once 'config/db.php';

                $stmt = $pdo->query("SELECT * FROM programmes");
                $programmes = $stmt->fetchAll();
                require 'app/views/admin/admin_dashboard.php';
                break;


            case 'programmeList':
                StudentController::programmeList($pdo);
                break;
            case 'registerInterestForm':
                StudentController::showRegisterForm($pdo);
                break;

            case 'registerInterest':
            case 'register':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    StudentController::registerInterest($pdo);
                }
                break;
            case 'addInterest':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    StudentController::addInterest($pdo);
                }
                break;
            case 'dashboard':
                StudentController::dashboard($pdo);
                break;

            case 'addInterest':
                echo "Routing to addInterest worked.";
                exit;
            case 'programmes':
                StudentController::index($pdo);
                break;

            case 'programme':
                if (isset($_GET['id'])) {
                    $id = (int) $_GET['id'];
                    StudentController::show($pdo, $id);
                }
                break;

            //  Admin
            // case 'adminLogin':
           
            case 'adminLoginSubmit':
                AdminController::login($pdo);
                break;

            case 'adminDashboard':
                require_once 'config/db.php';

                $stmt = $pdo->query("SELECT * FROM programmes");
                $programmes = $stmt->fetchAll();
                require 'app/views/admin/admin_dashboard.php';
                break;

            case 'addProgrammeForm':
                AdminController::addProgrammeForm($pdo);
                break;

            case 'addProgramme':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    AdminController::addProgramme($pdo);
                }
                break;

            case 'editProgrammeForm':
            case 'editProgramme':
                AdminController::editProgramme($pdo, isset($_GET['id']) ? (int) $_GET['id'] : null);
                break;

            case 'updateProgramme':
                AdminController::updateProgramme($pdo);
                break;

            case 'deleteProgramme':
                if (isset($_GET['id'])) {
                    $id = (int) $_GET['id'];
                    AdminController::deleteProgramme($pdo, $id);
                }
                break;

            case 'togglePublish':
                $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
                AdminController::togglePublish($pdo, $id);
                break;

            case 'programmeModules':
                $programmeId = isset($_GET['id']) ? (int) $_GET['id'] : null;
                AdminController::programmeModules($pdo, $programmeId);
                break;

            case 'assignModule':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    AdminController::assignModule($pdo);
                }
                break;

            case 'removeModule':
                if (isset($_GET['programmeId'], $_GET['moduleId'])) {
                    AdminController::removeModule($pdo, $_GET['programmeId'], $_GET['moduleId']);
                }
                break;

            case 'assignModuleLeaderForm':
                $moduleId = (int) ($_GET['id'] ?? 0);
                AdminController::assignModuleLeaderForm($pdo, $moduleId);
                break;

            case 'assignModuleLeader':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    AdminController::assignModuleLeader($pdo);
                }
                break;

            case 'mailingList':
                AdminController::mailingList($pdo);
                break;

            case 'downloadCSV':
                AdminController::downloadCSV($pdo);
                break;

            case 'exportEmails':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    AdminController::exportEmails($pdo);
                }
                break;

            case 'programmeList':
                AdminController::programmeList($pdo);
                break;
            case 'loginForm':
                StudentController::loginForm();
                break;
            //  Logout
            case 'logout':
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                session_destroy();
                header("Location: index.php?page=loginForm");
                exit;

                break;

            case 'adminLoginForm':
                AdminController::loginForm();
                break;

            case 'adminLogout':
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                session_destroy();
                header("Location: index.php?page=adminLoginForm");
                exit;
                break;

            //Staff

            case 'staffLoginForm':
                StaffController::loginForm();
                break;

            case 'staffLogin':
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    StaffController::login($pdo);
                }
                break;


            case 'staffImpact':
                StaffController::impact($pdo); 
                break;

            case 'staffLogout':
                StaffController::logout();
                break;

            case 'staffDashboard':
                StaffController::dashboard($pdo);
                break;
            case 'staffModules':
                StaffController::modules($pdo);
                break;


            //  error 404
            default:
                http_response_code(404);
                include('views/error/404.php');
        }
    }
}
