<?php
class Validator {
    public static function isEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function isNotEmpty(string $value): bool {
        return trim($value) !== '';
    }
}