<?php
require_once __DIR__.'/Csrf.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::validate()) {
        http_response_code(419);
        die('Invalid CSRF token.');
    }
}