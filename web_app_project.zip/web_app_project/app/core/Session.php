<?php
class Session {
    public static function start() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function isAdmin(): bool {
        self::start();
        return isset($_SESSION['admin']);
    }

    public static function logout() {
        self::start();
        session_unset();
        session_destroy();
    }
}