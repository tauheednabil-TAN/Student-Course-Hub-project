<?php
class Controller {
    protected function redirect(string $page) {
        header("Location: index.php?page=$page");
        exit;
    }

    protected function requireAdmin() {
        session_start();
        if (empty($_SESSION['admin'])) {
            $this->redirect('adminLogin');
        }
    }
}