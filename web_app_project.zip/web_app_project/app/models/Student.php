<?php
class Student
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function findByEmail(string $email): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM Students WHERE Email = :email");
        $stmt->execute(['email' => strtolower($email)]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function verifyPassword(string $email, string $password): ?array
    {
        $student = $this->findByEmail($email);
        if (!$student || !password_verify($password, $student['PasswordHash'])) {
            return null;
        }
        return $student;
    }

    public function create(string $name, string $email, string $passwordHash): bool
    {
        $stmt = $this->pdo->prepare("INSERT INTO Students (Name, Email, PasswordHash) VALUES (:name, :email, :password)");
        return $stmt->execute([
            'name' => $name,
            'email' => strtolower($email),
            'password' => $passwordHash
        ]);
    }

    public function emailExists(string $email): bool
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM Students WHERE Email = :email");
        $stmt->execute(['email' => strtolower($email)]);
        return (int) $stmt->fetchColumn() > 0;
    }
public function getInterestRows(string $email): array {
    $stmt = $this->pdo->prepare("
        SELECT p.ProgrammeName, i.RegisteredAt
        FROM interestedstudents i
        JOIN programmes p ON i.ProgrammeID = p.ProgrammeID
        WHERE i.Email = ?
    ");
    $stmt->execute([$email]);
    return $stmt->fetchAll();
}
}