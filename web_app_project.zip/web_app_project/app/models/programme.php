<?php
class Programme
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function all(): array
    {
        $sql = "SELECT p.ProgrammeID, p.ProgrammeName, p.Description, p.Image, p.is_published,
                       l.LevelName,
                       s.Name AS LeaderName
                FROM programmes p
                JOIN levels l ON p.LevelID = l.LevelID
                LEFT JOIN staff s ON p.ProgrammeLeaderID = s.StaffID
                ORDER BY p.ProgrammeID DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function published(): array
    {
        $sql = "SELECT ProgrammeID, ProgrammeName, Description, Image
                FROM programmes
                WHERE is_published = 1
                ORDER BY ProgrammeID DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int $id): ?array
    {
        $sql = "SELECT * FROM programmes WHERE ProgrammeID = :id LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function create(string $name, string $description, ?string $image = null, ?int $leaderId = null): int|false
    {
        $sql = "INSERT INTO programmes (ProgrammeName, Description, Image, ProgrammeLeaderID, is_published)
                VALUES (:name, :description, :image, :leaderId, 0)";
        $stmt = $this->pdo->prepare($sql);
        $ok = $stmt->execute([
            ':name' => $name,
            ':description' => $description,
            ':image' => $image,
            ':leaderId' => $leaderId
        ]);
        return $ok ? (int) $this->pdo->lastInsertId() : false;
    }

    public function update(int $id, string $name, string $description, ?string $image, ?int $leaderId, int $isPublished): bool
    {
        $sql = "UPDATE programmes
                SET ProgrammeName = :name,
                    Description = :description,
                    Image = :image,
                    ProgrammeLeaderID = :leaderId,
                    is_published = :isPublished
                WHERE ProgrammeID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'id' => $id,
            'name' => $name,
            'description' => $description,
            'image' => $image,
            'leaderId' => $leaderId,
            'isPublished' => $isPublished
        ]);
    }

    public function delete(int $id): bool
    {
        $sql = "DELETE FROM programmes WHERE ProgrammeID = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute(['id' => $id]);
    }

    public function togglePublish(int $id): bool
    {
        if ($id <= 0) return false;
        $stmt = $this->pdo->prepare("UPDATE programmes SET is_published = 1 - is_published WHERE ProgrammeID = :id");
        return $stmt->execute([':id' => $id]);
    }

    public function modulesByYear(int $programmeId): array
    {
        if ($programmeId <= 0) return [];

        $sql = "SELECT pm.Year, m.ModuleID, m.ModuleName, m.Description
                FROM programmemodules pm
                JOIN modules m ON pm.ModuleID = m.ModuleID
                WHERE pm.ProgrammeID = :programmeId
                ORDER BY pm.Year, m.ModuleName";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':programmeId' => $programmeId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $out = [];
        foreach ($rows as $r) {
            $year = $r['Year'] ?? 'Unknown';
            if (!isset($out[$year])) $out[$year] = [];
            $out[$year][] = [
                'ModuleID' => $r['ModuleID'],
                'ModuleName' => $r['ModuleName'],
                'Description' => $r['Description']
            ];
        }
        return $out;
    }

    public function leader(?int $staffId): ?array
    {
        $staffId = (int) $staffId;
        if ($staffId <= 0) return null;

        $stmt = $this->pdo->prepare("SELECT StaffID, Name FROM staff WHERE StaffID = :id LIMIT 1");
        $stmt->execute([':id' => $staffId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function getLevels(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM levels ORDER BY LevelID");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStaff(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM staff ORDER BY StaffID");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insert(string $name, string $description, ?string $image, int $levelId, ?int $leaderId, int $isPublished): bool
    {
        $sql = "INSERT INTO programmes (ProgrammeName, Description, Image, LevelID, ProgrammeLeaderID, is_published)
                VALUES (:name, :description, :image, :levelId, :leaderId, :isPublished)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'name' => $name,
            'description' => $description,
            'image' => $image,
            'levelId' => $levelId,
            'leaderId' => $leaderId,
            'isPublished' => $isPublished
        ]);
    }

    public function interestedStudents(): array
    {
        $sql = "SELECT i.StudentName, i.Email, i.RegisteredAt, p.ProgrammeName
                FROM interestedstudents i
                JOIN programmes p ON i.ProgrammeID = p.ProgrammeID
                ORDER BY i.RegisteredAt DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getModules(int $programmeId): array
    {
        $sql = "SELECT pm.Year, m.ModuleName, m.ModuleID,
                       s.Name AS LeaderName, s.Email, s.Bio
                FROM programmemodules pm
                JOIN modules m ON pm.ModuleID = m.ModuleID
                LEFT JOIN staff s ON m.ModuleLeaderID = s.StaffID
                WHERE pm.ProgrammeID = :id
                ORDER BY pm.Year, m.ModuleName";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $programmeId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function allModules(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM modules ORDER BY ModuleName");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function assignModule(int $programmeId, int $moduleId, int $year): bool
    {
        $sql = "INSERT INTO programmemodules (ProgrammeID, ModuleID, Year)
                VALUES (:programmeId, :moduleId, :year)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'programmeId' => $programmeId,
            'moduleId' => $moduleId,
            'year' => $year
        ]);
    }

    public function removeModule(int $programmeId, int $moduleId): bool
    {
        $sql = "DELETE FROM programmemodules
                WHERE ProgrammeID = :programmeId AND ModuleID = :moduleId";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'programmeId' => $programmeId,
            'moduleId' => $moduleId
        ]);
    }

    public function findModule(int $id): ?array
    {
        $sql = "SELECT m.*, s.Name AS LeaderName
                FROM modules m
                LEFT JOIN staff s ON m.ModuleLeaderID = s.StaffID
                WHERE m.ModuleID = :id LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

        public function updateModuleLeader(int $moduleId, int $leaderId): bool
    {
        $sql = "UPDATE modules SET ModuleLeaderID = :leaderId WHERE ModuleID = :moduleId";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'moduleId' => $moduleId,
            'leaderId' => $leaderId
        ]);
    }

    public function getAllStaffForModuleLeader(): array
    {
        $stmt = $this->pdo->query("SELECT StaffID, Name, Email FROM staff ORDER BY Name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getProgrammesUsingModule(int $moduleId): array
    {
        $sql = "SELECT p.ProgrammeID, p.ProgrammeName
                FROM programmemodules pm
                JOIN programmes p ON pm.ProgrammeID = p.ProgrammeID
                WHERE pm.ModuleID = :moduleId
                ORDER BY p.ProgrammeName";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['moduleId' => $moduleId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function moduleUsageCount(int $moduleId): int
    {
        $sql = "SELECT COUNT(DISTINCT ProgrammeID) FROM programmemodules WHERE ModuleID = :moduleId";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['moduleId' => $moduleId]);
        return (int) $stmt->fetchColumn();
    }
}