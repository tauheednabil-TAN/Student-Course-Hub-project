<?php
class InterestedStudent
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function exists(string $email, int $programmeId): bool
    {
        $sql = "SELECT COUNT(*) FROM interestedstudents WHERE Email = ? AND ProgrammeID = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([strtolower($email), $programmeId]);
        return (int) $stmt->fetchColumn() > 0;
    }

   public function register(string $name, string $email, int $programmeId): void {
    $stmt = $this->pdo->prepare("
 INSERT INTO interestedstudents (StudentName, Email, ProgrammeID, RegisteredAt) VALUES (?, ?, ?, NOW())
");
    $stmt->execute([$name, $email, $programmeId]);
}
}