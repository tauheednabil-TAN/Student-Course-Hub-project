README — Task Files Bundle
==========================
This archive contains ONLY the files and snippets related to the JavaScript + Security tasks.
Use it to manually integrate changes into your previous project or keep as GitHub evidence.

Order:
1) Copy new files (PHP/JS)
2) Apply patches (index.php, ProgrammesController.php)
3) Insert CSRF snippet in forms
4) Add floating Home box + JS include before </body>
5) Run SQL/alter_auth_columns.sql