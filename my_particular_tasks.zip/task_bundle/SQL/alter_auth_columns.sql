-- Add PasswordHash column to each auth table (if not already present)
-- If your MySQL version doesn't support IF NOT EXISTS on columns,
-- run a DESCRIBE first and add the column conditionally.
ALTER TABLE `students` ADD COLUMN `PasswordHash` VARCHAR(255) NULL AFTER `Email`;
ALTER TABLE `staff`    ADD COLUMN `PasswordHash` VARCHAR(255) NULL AFTER `Email`;
ALTER TABLE `admins`   ADD COLUMN `PasswordHash` VARCHAR(255) NULL AFTER `Email`;

-- Optional: enforce unique emails
ALTER TABLE `students` ADD UNIQUE KEY `uniq_students_email` (`Email`);
ALTER TABLE `staff`    ADD UNIQUE KEY `uniq_staff_email` (`Email`);
ALTER TABLE `admins`   ADD UNIQUE KEY `uniq_admins_email` (`Email`);
