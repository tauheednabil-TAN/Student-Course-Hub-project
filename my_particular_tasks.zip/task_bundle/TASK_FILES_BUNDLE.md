# TASK FILES BUNDLE
Includes only the task-related files I added/modified.

New Files:
- app/core/Csrf.php
- app/core/PostGuard.php
- public/assets/programme-ui.js
- app/controllers/StaffController.php (only if you didn’t have it)

Replacement:
- app/controllers/LoginController.php (secure)

Patches:
- PATCHES/index.php.patch
- PATCHES/ProgrammesController.php.patch
- PATCHES/Views_CSRF_Insertions.patch
- PATCHES/Add_Home_Button_And_JS.patch

SQL:
- SQL/alter_auth_columns.sql