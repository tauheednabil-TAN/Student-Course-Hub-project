// programme-ui.js — interactivity, validation, sanitization, confirmations, home button
document.addEventListener('DOMContentLoaded', () => {
  const isProgrammePage =
    /page=programmes/i.test(location.search) ||
    Array.from(document.querySelectorAll('a')).some(a => /page=programmeDetails/i.test(a.href));
  const listContainers = document.querySelectorAll('.programme-list, .programmes, ul');
  if (isProgrammePage && listContainers.length) {
    const target = listContainers[0];
    if (!document.getElementById('programme-search-bar')) {
      const wrap = document.createElement('div');
      wrap.id = 'programme-search-bar';
      wrap.style.margin = '12px 0';
      wrap.innerHTML = `
        <form action="index.php" method="get" style="display:flex; gap:8px; max-width:520px;">
          <input type="hidden" name="page" value="programmes">
          <input type="search" name="q" placeholder="Search programmes by name or keyword" aria-label="Search programmes" style="flex:1; padding:8px;">
          <button type="submit" class="btn">Search</button>
        </form>`;
      target.parentNode.insertBefore(wrap, target);
    }
    const input = document.querySelector('#programme-search-bar input[type="search"]');
    input?.addEventListener('input', () => {
      const q = (input.value || '').trim().toLowerCase();
      target.querySelectorAll('li').forEach(li => {
        const t = li.textContent.toLowerCase();
        li.style.display = t.includes(q) ? '' : 'none';
      });
    });
  }
  const yearGroups = document.querySelectorAll('[data-year]');
  if (yearGroups.length) {
    const years = [...new Set([...yearGroups].map(el => el.getAttribute('data-year')))].sort();
    const bar = document.createElement('div');
    bar.style.display='flex'; bar.style.gap='8px'; bar.style.margin='10px 0';
    years.forEach(yr => {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = `Year ${yr}`;
      b.onclick = () => {
        yearGroups.forEach(el => el.style.display = (el.getAttribute('data-year') === yr) ? '' : 'none');
      };
      bar.appendChild(b);
    });
    yearGroups[0].parentNode.insertBefore(bar, yearGroups[0]);
  }
  document.body.addEventListener('click', (e) => {
    const t = e.target.closest('[data-confirm], .btn-delete, .danger, .delete');
    if (t && (t.tagName === 'A' || t.tagName === 'BUTTON' || t.closest('form'))) {
      const msg = t.getAttribute('data-confirm') || 'Are you sure you want to proceed?';
      if (!confirm(msg)) e.preventDefault();
    }
  });
  const sanitize = v => (v||'').toString().replace(/\s+/g,' ').trim().replace(/[\x00-\x1F\x7F]/g,'').replace(/[<>]/g,'');
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
      let ok = true;
      form.querySelectorAll('[required]').forEach(inp => {
        const val = sanitize(inp.value);
        if (!val) {
          ok=false; inp.setAttribute('aria-invalid','true');
          if (!inp.nextElementSibling || !inp.nextElementSibling.classList.contains('js-error')) {
            const small=document.createElement('small'); small.className='js-error'; small.style.color='#c00';
            small.textContent='This field is required'; inp.insertAdjacentElement('afterend', small);
          }
        } else {
          inp.removeAttribute('aria-invalid');
          if (inp.nextElementSibling?.classList.contains('js-error')) inp.nextElementSibling.remove();
        }
      });
      form.querySelectorAll('input[type="email"]').forEach(inp=>{
        const v = sanitize(inp.value);
        const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
        if (!valid) {
          ok=false; inp.setAttribute('aria-invalid','true');
          if (!inp.nextElementSibling || !inp.nextElementSibling.classList.contains('js-error')) {
            const small=document.createElement('small'); small.className='js-error'; small.style.color='#c00';
            small.textContent='Enter a valid email address'; inp.insertAdjacentElement('afterend', small);
          }
        }
      });
      const consent = form.querySelector('input[name="consent"], #consent');
      if (consent && !consent.checked) { ok=false; alert('Please provide consent to proceed.'); }
      form.querySelectorAll('input[type="text"], input[type="search"], input[type="tel"], textarea').forEach(inp=>{
        inp.value = sanitize(inp.value);
      });
      if (!ok) e.preventDefault();
    });
  });
  if (!document.querySelector('.go-home-box')) {
    const box = document.createElement('div');
    box.className='go-home-box';
    box.style.cssText='position:fixed;right:16px;bottom:16px;z-index:9999';
    box.innerHTML = `<a href="index.php?page=home" style="display:inline-block;padding:10px 14px;border-radius:10px;background:#f5f7fb;border:1px solid #dce1ef;box-shadow:0 2px 10px rgba(0,0,0,0.08);text-decoration:none;font-family:system-ui,Arial,sans-serif;color:#1e3c72;">⟵ Go to Homepage</a>`;
    document.body.appendChild(box);
  }
});
