<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
$type = $_GET['type'] ?? '';
require_once 'config/db.php';
$validTypes = ['student', 'staff', 'admin'];
if (!in_array($type, $validTypes, true)) {
  http_response_code(400);
  echo "Invalid login type.";
  exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = strtolower(trim($_POST['email'] ?? ''));
  $password = $_POST['password'] ?? '';
  if ($email === '' || $password === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<p style='color:red; text-align:center;'>Enter a valid email and password.</p>";
    require "app/views/login/{$type}_login.php";
    exit;
  }
  $table = $type === 'student' ? 'students' : ($type === 'staff' ? 'staff' : 'admins');
  $idCol = $type === 'student' ? 'StudentID' : ($type === 'staff' ? 'StaffID' : 'AdminID');
  $emailCol = 'Email';
  $nameCol  = 'Name';
  $hashCol  = 'PasswordHash';
  $stmt = $pdo->prepare("SELECT * FROM {$table} WHERE {$emailCol} = :email LIMIT 1");
  $stmt->execute([':email' => $email]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);
  $ok = $user && !empty($user[$hashCol]) && password_verify($password, $user[$hashCol]);
  if ($ok) {
    $_SESSION[$type] = [
      'id'    => $user[$idCol] ?? null,
      'name'  => $user[$nameCol] ?? ucfirst($type),
      'email' => $user[$emailCol] ?? ''
    ];
    header("Location: index.php?page={$type}Dashboard");
    exit;
  } else {
    echo "<p style='color:red; text-align:center;'>Invalid credentials</p>";
    require "app/views/login/{$type}_login.php";
    exit;
  }
} else {
  require "app/views/login/{$type}_login.php";
}
