<?php
class StaffController {
  public static function loginForm(): void {
    include __DIR__.'/../views/staff/staff_loginForm.php';
  }
  public static function dashboard(PDO $pdo): void {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    $staff = $_SESSION['staff'] ?? null;
    if (!$staff) { header('Location: index.php?page=login&type=staff'); exit; }
    $stmt = $pdo->prepare("SELECT * FROM modules WHERE ModuleLeaderID = :id ORDER BY ModuleID DESC");
    $stmt->execute([':id' => $staff['id']]);
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    include __DIR__.'/../views/staff/staff_dashboard.php';
  }
  public static function impact(PDO $pdo): void {
    $staffId = (int)($_GET['id'] ?? 0);
    $sql = "SELECT p.ProgrammeName, COUNT(pm.ModuleID) AS ModuleCount
              FROM modules m
              JOIN programmemodules pm ON pm.ModuleID = m.ModuleID
              JOIN programmes p ON pm.ProgrammeID = p.ProgrammeID
             WHERE m.ModuleLeaderID = :id
             GROUP BY p.ProgrammeID, p.ProgrammeName
             ORDER BY ModuleCount DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $staffId]);
    $impact = $stmt->fetchAll(PDO::FETCH_ASSOC);
    include __DIR__.'/../views/staff/staff_impact.php';
  }
}
